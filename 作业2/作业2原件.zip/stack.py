stack = []

def push(obj):
    global stack
    
def pop():
    global stack
  
def isEmpty():
