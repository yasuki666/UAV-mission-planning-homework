queue = []

def enqueue(obj):
    global queue
   
def dequeue():
    global queue

def isEmpty():

