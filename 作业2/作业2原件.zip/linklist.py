class Node:
    def __init__(self,key):
        self.key = key
        self.next = None
        
class LinkList:
    def __init__(self,node=None): # 使用一个默认参数，在传入头结点时则接收，在没有传入时，就默认头结点为空
        self.head = node
    
    def isEmpty(self):
        if self.head == None:
            return True
        else:        
            return False       

    def travel(self): #遍历整个列表
        cur = self.head
        while cur != None:
            print(cur.key, end=' ')
            cur = cur.next
        print("\n")
  
    def add(self, obj):   #链表头部添加元素
        node = Node(obj)
        node.next = self.head
        self.head = node
               
#    def append(self, obj):  #链表尾部添加元素
    
#    def insert(self, pos, obj):  #在链表的pos处插入关键字为obj的元素
                     
#    def search(self, obj):  #查询关键字为obj的结点          
    
#    def remove(self, obj):  #删除所有关键字为obj的结点

#    def length(self): #求链表长度
        
head = LinkList()
head.add(10)
head.add(20)
head.add(30)
head.travel()

